<?php $__env->startSection('head'); ?>
    <title>Деревня Мувыр — Как добраться?</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    О нас
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/about.blade.php ENDPATH**/ ?>