<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Новость fixme</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="intro_article">
        <header class="my-3">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img">
                </button>
            </div>
        </header>

        <div class="intro__content position_intro_content">
            <div class="container">
                <h1 class="intro__title_substr txt24 date_title"><?php echo e(mb_strimwidth($new->date_post, 0, 11)); ?></h1>
                <h1 class="intro__title name_title"><?php echo e($new->title_post); ?></h1>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="article_page">
        <div class="container container_news">

            <p class="justified_txt">
                <?php echo e($new->description_post); ?>

            </p>
            <div class="article_box_img">
                <img src="/<?php echo e($new->img_post); ?>">
            </div>
            <div class="social_net_comments">
                <div class="social_net_comments_content">
                    <p class="wh gr">Комментарии: </p>
                    <a href=""><img src="<?php echo e(asset('assets/img/vk_gr.svg')); ?>"></a>
                    <a href=""><img src="<?php echo e(asset('assets/img/inst_gr.svg')); ?>"></a>
                </div>
            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/new.blade.php ENDPATH**/ ?>