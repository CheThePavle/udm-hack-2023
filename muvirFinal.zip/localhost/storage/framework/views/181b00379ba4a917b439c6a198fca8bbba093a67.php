<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Экскурсия fixme</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="intro_article inro_single_excursion">
        <header class="my-3">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img">
                </button>
            </div>
        </header>

        <div class="intro__content position_intro_content">
            <div class="container">
                <h1 class="intro__title name_title"><?php echo e($excursion->title_exc); ?></h1>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="article_page">
        <div class="container container_news">
            <p class="title txt24">
                С одного человека: <?php echo e(number_format($excursion->price_exc, 2, ',', ' ')); ?> ₽
            </p>
            <p class="title txt24">
                <?php echo e($excursion->phone_exc); ?>

            </p>
            <br>
            <p class="justified_txt">
                <?php echo e($excursion->description_exc); ?>

            </p>
            <div class="article_box_img excursion_img">
                <img src="/<?php echo e($excursion->img_exc); ?>">
            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/excursion.blade.php ENDPATH**/ ?>