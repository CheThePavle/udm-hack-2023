<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Интерактивная карта</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="intro_article inro_single_excursion">
            <header class="my-3">
                <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                        <img src="assets/img/logoround.jpg" class="logo_img">
                    </a>

                    <button class="menu_btn" id="menu_btn">
                        <img class="menu_btn_img" src="assets/img/menu.svg" id="menu_btn_img">
                    </button>
                </div>
            </header>

            <div class="intro__content position_intro_content">
                <div class="container">
                    <h1 class="intro__title name_title">ИНВЕСТОРАМ</h1>
                </div>
            </div>
        </div>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="article_page">
        <div class="container container_news">
            <div class="service_block end_block">
                <div class="service_block_content">
                    <p class="txt58 gr">СТРОИТЕЛЬСТВО ГЭС</p>
                    <img class="my-4" src="assets/img/ges.png">

                    <p class="justified_txt">Уважаемые инвесторы,
                    </p>
                    <p class="justified_txt">В современном мире сохранение энергетической стабильности и постоянное
                        развитие возобновляемых источников энергии становятся все более важными задачами для общества.
                        Производство и использование энергии являются ключевыми факторами экономического роста, особенно
                        в странах, где энергетическая инфраструктура нуждается в модернизации.</p>

                        <p class="justified_txt">Восстановление ГЭС:<br>
                        ГЭС — это не только эффективный способ для генерации энергии, но и надежный инструмент для
                        создания устойчивого энергетического сектора. Восстановление старых или устаревших ГЭС открывает
                        новые перспективы для обеспечения стабильного источника энергии, а также снижения негативного
                        влияния на окружающую среду.</p>

                        <p class="justified_txt">Инвестиции в восстановление ГЭС связаны с рядом преимуществ:</p>

                        <p class="justified_txt">1. Увеличение энергетической независимости:<br>
                        Восстановление ГЭС позволит нам увеличить мощности генерации электроэнергии и обеспечить нашу
                        деревню собственным источником энергии. Это уменьшит зависимость от импорта энергоресурсов и
                        обеспечит энергетическую независимость.</p>

                        <p class="justified_txt">2. Развитие экологически чистого энергетического сектора:<br>
                        ГЭС являются одним из самых экологически чистых источников энергии, не производящих выбросов
                        вредных веществ или парниковых газов. Восстановление старых ГЭС и внедрение новых технологий
                        поможет нам снизить загрязнение окружающей среды и решить проблемы климатических изменений.</p>

                        <p class="justified_txt">3. Создание рабочих мест и экономический рост:<br>
                        Восстановление ГЭС потребует вложений в строительство и обновление инфраструктуры, что позволит
                        развивать строительный сектор и создать новые рабочие места. Помимо этого, развитие ГЭС
                        способствует привлечению иностранных инвестиций, развитию местной экономики и укреплению
                        инфраструктурных возможностей.</p>

                        <p class="justified_txt">Мы приглашаем вас присоединиться к нам и восстановить ГЭС, которая поможет в развитии нашей
                        деревни и регион, вы можете сделать реальный и значимый вклад в процветание нашего общества.</p>

                    </p>
                    <p class="justified_txt">С уважением,<br>
                        Наша маленькая деревня Мувыр.
                    </p>
                </div>
            </div>

        </div>

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/map.blade.php ENDPATH**/ ?>