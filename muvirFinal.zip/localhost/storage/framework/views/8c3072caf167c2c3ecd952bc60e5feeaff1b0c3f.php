<?php $__env->startSection('head'); ?>
    <title>Админ панель — Добавление мероприятия</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding end_block">

        <div class="container my-4">
            <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="posts_block my-4">
                <p class="txt24 bl publ_txt"><?php echo e(Route::is('adminPostChange') ? 'ИЗМЕНЕНИЕ МЕРОПРИЯТИЯ' : 'НОВОЕ МЕРОПРИЯТИЕ'); ?></p>

                <form action="<?php echo e(Route::is('adminPostChange') ? route('changePost') : route('createPost')); ?>" method="post" class="info_item" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <?php if(Route::is('adminPostChange')): ?>
                        <?php echo method_field("PATCH"); ?>

                        <input type="hidden" name="id_post" value="<?php echo e($post->id_post); ?>">
                    <?php endif; ?>

                    <label class="add_input">Название: <br><input value="<?php echo e(Route::is('adminPostChange') ? $post->title_post : old('title_post') ?? ''); ?>" name="title_post" type="text"
                                                                  class="inputline add_input" placeholder="Название мероприятия" required maxlength="255"></label><br>

                    <?php if(Route::is('adminPostChange')): ?>
                        <img src="/<?php echo e($post->img_post); ?>" alt="img">
                    <?php endif; ?>
                    <label class="add_input"><?php echo e(Route::is('adminPostChange') ? 'Изменить ' : ''); ?>Фото: <input name="img_post" type="file" placeholder="Фото" <?php echo e(Route::is('adminPostChange') ? '' : 'required'); ?>></label>

                    <label class="add_input">Описание: <br><textarea name="description_post"
                                                                     placeholder="Описание мероприятия" class="add_input description"
                                                                     required><?php echo e(Route::is('adminPostChange') ? $post->description_post : old('description_post') ?? ''); ?></textarea></label>

                    <button class="more_info_white_btn" type="submit"><?php echo e(Route::is('adminPostChange') ? 'Изменить' : 'Опубликовать'); ?></button>

                    <p class="err">
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </p>
                </form>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/admin/add/new.blade.php ENDPATH**/ ?>