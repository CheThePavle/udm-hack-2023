<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Досуг</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="intro_news intro_fun">
        <header class="my-3">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img">
                </button>
            </div>
        </header>

        <div class="intro__content position_intro_content">
            <div class="container">
                <h1 class="intro__title name_page">ДОСУГ В МУВЫРЕ</h1>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="news_page end_block">
        <div class="container">
            <div class="fun_row">

                <?php if(count($funs) > 0): ?>
                    <?php $__currentLoopData = $funs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="news_card">
                            <div class="fun_card">
                                <div class="fun_card_box_img">
                                    <img src="/<?php echo e($fun->img_fun); ?>">
                                </div>
                                <div class="news_card_txt vertical_align">
                                    <div class="txt_first">
                                        <p class="title txt24">
                                            <?php echo e($fun->title_fun); ?>

                                        </p>
                                        <p class="descr justified_txt">
                                            <?php echo e($fun->description_fun); ?>

                                        </p>
                                    </div>

                                    <div class="txt_second">
                                        <p class="descr">
                                            <?php echo e($fun->phone_fun); ?>

                                        </p>
                                        <p class="title txt24">
                                            <?php echo e(number_format($fun->price_fun, 2, ',', ' ')); ?> ₽
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div>
                        Ничего не найдено
                    </div>
                <?php endif; ?>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/fun.blade.php ENDPATH**/ ?>