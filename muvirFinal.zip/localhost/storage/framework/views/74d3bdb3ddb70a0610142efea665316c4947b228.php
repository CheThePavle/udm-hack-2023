<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Контакты</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Контакты
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/contact.blade.php ENDPATH**/ ?>