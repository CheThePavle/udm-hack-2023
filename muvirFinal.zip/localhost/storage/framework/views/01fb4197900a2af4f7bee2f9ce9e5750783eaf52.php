<?php $__env->startSection('head'); ?>
    <title>Деревня Мувыр — Продукция</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    наша продукция

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/products.blade.php ENDPATH**/ ?>