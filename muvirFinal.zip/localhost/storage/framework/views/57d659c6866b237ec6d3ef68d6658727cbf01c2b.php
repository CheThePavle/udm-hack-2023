<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>" defer></script>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/style/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/style/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/style/media.css')); ?>">
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
    <div class="wrap">
        <?php echo $__env->yieldContent('content'); ?>

        <footer>
            <div class="container">
                <div class="footer_content">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>">
                    <div class="footer_txt">
                        <div class="social_net">
                            <p class="wh">Мы в социальных сетях: </p>
                            <a href=""><img src="<?php echo e(asset('assets/img/vk.svg')); ?>"></a>
                            <a href=""><img src="<?php echo e(asset('assets/img/inst.svg')); ?>"></a>
                        </div>
                        <p class="num wh">+7 (901) 865 87 55</p>
                        <ul class="wh ul_footer txt24">
                            <li><a href="">О нас</a></li>
                            <li><a href="">Контакты</a></li>
                            <li><a href="">Производство</a></li>
                            <li><a href="">Администраторам</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </footer>
    </div>

    <script src="<?php echo e(asset('assets/scripts/script.js')); ?>" defer></script>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\localhost\resources\views/layouts/app.blade.php ENDPATH**/ ?>