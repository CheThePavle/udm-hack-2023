<?php $__env->startSection('head'); ?>
    <title>Название страницы</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="intro_news intro_house">
        <header class="my-3 header_OP">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img logo_img_OP">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img" >
                </button>
            </div>
        </header>

        <div class="intro__content position_intro_content">
            <div class="container">
                <h1 class="intro__title name_page">ГОСТЕВЫЕ ДОМИКИ</h1>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <button class="menu_btn menu_btn_close" id="menu_btn_close">
        <img class="menu_btn_img" src="<?php echo e(asset('assets/img/close.svg')); ?>" id="menu_btn_img" >
    </button>

    <main class="news_page end_block">
        <div class="container">
            <div class="news_row">

                <div class="news_card vertical_align">
                    <div class="news_card_box_img">
                        <img src="<?php echo e(asset('assets/img/house_inside.jpg')); ?>">
                    </div>
                    <div class="news_card_txt">
                        <p class="title txt24">
                            Эко домик с видом на поле
                        </p>
                        <p class="descr justified_txt">
                            Заезд: после 14:00. Выезд: до 12:00
                            <br>
                            Туалет, умывальник на улице
                        </p>
                    </div><br>
                    <div class="service_btn_block">
                        <a href="" class="service_btn wh txt24">УЗНАТЬ БОЛЬШЕ →</a>
                    </div>
                </div>

                <div class="news_card vertical_align">
                    <div class="news_card_box_img">
                        <img src="<?php echo e(asset('assets/img/house_inside.jpg')); ?>">
                    </div>
                    <div class="news_card_txt">
                        <p class="title txt24">
                            Эко домик с видом на поле
                        </p>
                        <p class="descr justified_txt">
                            Заезд: после 14:00. Выезд: до 12:00
                            <br>
                            Туалет, умывальник на улице
                        </p>
                    </div><br>
                    <div class="service_btn_block">
                        <a href="" class="service_btn wh txt24">УЗНАТЬ БОЛЬШЕ →</a>
                    </div>
                </div>

                <div class="news_card vertical_align">
                    <div class="news_card_box_img">
                        <img src="<?php echo e(asset('assets/img/house_inside.jpg')); ?>">
                    </div>
                    <div class="news_card_txt">
                        <p class="title txt24">
                            Эко домик с видом на поле
                        </p>
                        <p class="descr justified_txt">
                            Заезд: после 14:00. Выезд: до 12:00
                            <br>
                            Туалет, умывальник на улице
                        </p>
                    </div><br>
                    <div class="service_btn_block">
                        <a href="" class="service_btn wh txt24">УЗНАТЬ БОЛЬШЕ →</a>
                    </div>
                </div>

                <div class="news_card vertical_align">
                    <div class="news_card_box_img">
                        <img src="<?php echo e(asset('assets/img/house_inside.jpg')); ?>">
                    </div>
                    <div class="news_card_txt">
                        <p class="title txt24">
                            Эко домик с видом на поле
                        </p>
                        <p class="descr justified_txt">
                            Заезд: после 14:00. Выезд: до 12:00
                            <br>
                            Туалет, умывальник на улице
                        </p>
                    </div><br>
                    <div class="service_btn_block">
                        <a href="" class="service_btn wh txt24">УЗНАТЬ БОЛЬШЕ →</a>
                    </div>
                </div>

                <div class="news_card vertical_align">
                    <div class="news_card_box_img">
                        <img src="<?php echo e(asset('assets/img/house_inside.jpg')); ?>">
                    </div>
                    <div class="news_card_txt">
                        <p class="title txt24">
                            Эко домик с видом на поле
                        </p>
                        <p class="descr justified_txt">
                            Заезд: после 14:00. Выезд: до 12:00
                            <br>
                            Туалет, умывальник на улице
                        </p>
                    </div><br>
                    <div class="service_btn_block">
                        <a href="" class="service_btn wh txt24">УЗНАТЬ БОЛЬШЕ →</a>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost\resources\views/houses.blade.php ENDPATH**/ ?>