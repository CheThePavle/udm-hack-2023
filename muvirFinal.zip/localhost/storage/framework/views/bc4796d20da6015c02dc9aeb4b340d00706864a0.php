<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Экскурсии</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="intro_news intro_house">

        <header class="my-3">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img">
                </button>
            </div>
        </header>

        <div class="intro__content position_intro_content">
            <div class="container">
                <h1 class="intro__title name_page">ЭКСКУРСИИ В МУВЫРЕ</h1>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="news_page end_block">
        <div class="container">
            <div class="news_row">

                <?php if(count($excursions) > 0): ?>
                    <?php $__currentLoopData = $excursions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $excursion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="news_card vertical_align">
                            <div class="news_card_box_img">
                                <img src="/<?php echo e($excursion->img_exc); ?>">
                            </div>
                            <div class="news_card_txt">
                                <p class="title txt24  my-4">
                                    <?php echo e($excursion->title_exc); ?>

                                </p>
                                <p class="descr justified_txt">
                                    <?php echo e($excursion->description_exc); ?>

                                </p>
                                <p class="title txt24">
                                    <?php echo e(number_format($excursion->price_exc, 2, ',', ' ')); ?> ₽
                                </p>
                            </div><br>
                            <div class="service_btn_block">
                                <a href="<?php echo e(route('excursion', ['id' => $excursion->id_exc])); ?>" class="service_btn wh txt24">УЗНАТЬ БОЛЬШЕ →</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div>
                        Ничего не нашло
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/excursions.blade.php ENDPATH**/ ?>