<?php $__env->startSection('head'); ?>
    <title>Название страницы</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="intro_news intro_fun">
        <header class="my-3 header_OP">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img logo_img_OP">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img" >
                </button>
            </div>
        </header>

        <div class="intro__content position_intro_content">
            <div class="container">
                <h1 class="intro__title name_page">ДОСУГ В МУВЫРЕ</h1>
            </div>
        </div>
    </div>

    <nav id="nav" class="nav_list">
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="">Досуг в Мувыре</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Гостевые домики</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Мероприятия</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Экскурсии</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Свадьба в Мувыре</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Как добраться?</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Интерактивная карта</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">О нас</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Контакты</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Производство</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Инвесторам</a>
            </li>
        </ul>
    </nav>

    <button class="menu_btn menu_btn_close" id="menu_btn_close">
        <img class="menu_btn_img" src="<?php echo e(asset('assets/img/close.svg')); ?>" id="menu_btn_img" >
    </button>

    <main class="news_page end_block">
        <div class="container">
            <div class="fun_row">

                <div class="news_card">
                    <div class="fun_card">
                        <div class="fun_card_box_img">
                            <img src="<?php echo e(asset('assets/img/fun.png')); ?>">
                        </div>
                        <div class="news_card_txt vertical_align">
                            <div class="txt_first">
                                <p class="title txt24">
                                    Велопрокат
                                </p>
                                <p class="descr justified_txt">
                                    150 руб - 30 мин., 250 руб -1 час., 1000 руб - сутки
                                </p>
                            </div>

                            <div class="txt_second">
                                <p class="descr">
                                    +7 (901) 865 87 55
                                </p>
                                <p class="title txt24">
                                    150 ₽
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="news_card">
                    <div class="fun_card">
                        <div class="fun_card_box_img">
                            <img src="<?php echo e(asset('assets/img/fun.png')); ?>">
                        </div>
                        <div class="news_card_txt vertical_align">
                            <div class="txt_first">
                                <p class="title txt24">
                                    Велопрокат
                                </p>
                                <p class="descr justified_txt">
                                    150 руб - 30 мин., 250 руб -1 час., 1000 руб - сутки
                                </p>
                            </div>

                            <div class="txt_second">
                                <p class="descr">
                                    +7 (901) 865 87 55
                                </p>
                                <p class="title txt24">
                                    150 ₽
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="news_card">
                    <div class="fun_card">
                        <div class="fun_card_box_img">
                            <img src="<?php echo e(asset('assets/img/fun.png')); ?>">
                        </div>
                        <div class="news_card_txt vertical_align">
                            <div class="txt_first">
                                <p class="title txt24">
                                    Велопрокат
                                </p>
                                <p class="descr justified_txt">
                                    150 руб - 30 мин., 250 руб -1 час., 1000 руб - сутки
                                </p>
                            </div>

                            <div class="txt_second">
                                <p class="descr">
                                    +7 (901) 865 87 55
                                </p>
                                <p class="title txt24">
                                    150 ₽
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="news_card">
                    <div class="fun_card">
                        <div class="fun_card_box_img">
                            <img src="<?php echo e(asset('assets/img/fun.png')); ?>">
                        </div>
                        <div class="news_card_txt vertical_align">
                            <div class="txt_first">
                                <p class="title txt24">
                                    Велопрокат
                                </p>
                                <p class="descr justified_txt">
                                    150 руб - 30 мин., 250 руб -1 час., 1000 руб - сутки
                                </p>
                            </div>

                            <div class="txt_second">
                                <p class="descr">
                                    +7 (901) 865 87 55
                                </p>
                                <p class="title txt24">
                                    150 ₽
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost\resources\views/fun.blade.php ENDPATH**/ ?>