<nav id="nav" class="nav_list">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="">Досуг в Мувыре</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">Гостевые домики</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">Мероприятия</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">Экскурсии</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">Свадьба в Мувыре</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">Как добраться?</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">Интерактивная карта</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">О нас</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">Контакты</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">Производство</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">Инвесторам</a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\OpenServer\domains\localhost\resources\views/layouts/menu.blade.php ENDPATH**/ ?>