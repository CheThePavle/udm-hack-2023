<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Производство</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<header class="my-3">
            <div class="container">
                <a href="index.php">
                    <img src="assets/img/logoround.jpg" class="logo_img">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="assets/img/menu.svg" id="menu_btn_img">
                </button>
            </div>
        </header>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding">
            <div class="container">
                <p class="txt58 gr">НАША ПРОДУКЦИЯ</p>
                <div class="products_page">
                    <p class="products_txt">В 2019 году Фермерское хозяйство Корепанова А. Г. "д. Мувыр" выиграло грант
                        Министерства сельского хозяйства УР на постройку завода по переработке молока. Открытие
                        производства
                        состоялось в июне 2021 года.
                    <p class="products_txt">Александр Геннадьевич Корепанов:
                    <p class="quote">“Хочется накормить, угостить и влюбить в нашу качественную натуральную и просто
                        лучшую
                        молочную продукцию как можно больше людей!”</p>
                    <p class="products_txt">На сегодняшний день наш ассортимент и производство только продолжают расти.
                        Еще многое ждет впереди, но уже точно можно сказать, что наша молочная продукция — это наша
                        гордость и мы с радостью делимся ею с вами! Покупая нашу продукцию, вы предоставляете нам самое
                        ценное — самое дорогое, то, чем обладает каждый из наших покупателей: ваше доверие и признание к
                        продукции деревни Мувыр! Ради вас мы работаем, исполняем наши мечты и реализуем намеченные
                        проекты.
                    </p>
<p></p>
<p></p>
                    <p>
                    Адреса торговых точек в г. Ижевск, где возможно приобрести продукцию Мувырского молокозавода:<br>
г. Ижевск, ул. 9 января, 213, «Погода в доме»<br>
г Ижевск, ул. 9 Января, д.259<br>
г Ижевск, ул. Автозаводская, д. 50 г Ижевск, ул. Дзержинского, д. 48А г Ижевск, ул. Молодежная, д. 96<br>
г. Ижевск, ул. Молодежная, д. 101 г. Ижевск, ул. Молодежная, д.79В г. Ижевск, ул. Сабурова, 27а<br>
г Ижевск, ул. Ленина, 120А<br>
г Ижевск, ул. 40 лет Победы, д. 72 г Ижевск, ул. 40 лет Победы, д. 52 г Ижевск, ул. Ворошилова, д. 53 д. Хохряки, ул. Трактовая,д. 1. г.Ижевск, ул.Ракетная, 24, м-н «Карамель»<br>
г Ижевск, ул. Максима Горького, 149<br>
г. Ижевск, ул. Карла Маркса, д.393<br>
г. Ижевск, ул. Холмогорова, 24А<br>
г. Ижевск, ул. Гагарина, д. 49Б, ТЦ «Московский»<br>
г Ижевск, ул. Героя России Ильфата Закирова, д.21<br>
г. Ижевск, ул. Клубная, д.27<br>
г. Ижевск, ул. Выставочная, д. 3Б г. Ижевск, ул. Школьная, д.44А<br>
г. Ижевск, ул. Майская, д.9А<br>
г. Ижевск, ул. Карла Либкнехта, 51 г. Ижевск, ул. Клубная, 50<br>
г. Ижевск, ул. 8ая Подлесная, 48 г. Ижевск, ул. Карла Либнихта, 10 г. Ижевск, ул. Ордженикидзе, 36А г. Ижевск, ул. Ордженикидзе, 40 г. Ижевск, ул. Удмуртская, 304<br>
г. Ижевск, ул. Барышникова, 9<br>
г. Ижевск, ул. Пугачева, 43<br>
г. Ижевск, ул. Молодежная, 74<br>
г. Ижевск, ул. Дзержинского, 30<br>
г. Ижевск, ул. Ленина, 166А<br>
г. Ижевск, ул. Азина, 152<br>
г. Ижевск, ул. Репина, 215<br>
                    </p>
                </div>
            </div>

            <svg class="background_gradient" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 250"><path fill="#F1EFE0" fill-opacity="1" d="M0,160L14.1,181.3C28.2,203,56,245,85,240C112.9,235,141,181,169,138.7C197.6,96,226,64,254,85.3C282.4,107,311,181,339,192C367.1,203,395,149,424,117.3C451.8,85,480,75,508,90.7C536.5,107,565,149,593,154.7C621.2,160,649,128,678,106.7C705.9,85,734,75,762,90.7C790.6,107,819,149,847,165.3C875.3,181,904,171,932,186.7C960,203,988,245,1016,224C1044.7,203,1073,117,1101,74.7C1129.4,32,1158,32,1186,64C1214.1,96,1242,160,1271,170.7C1298.8,181,1327,139,1355,106.7C1383.5,75,1412,53,1426,42.7L1440,32L1440,0L1425.9,0C1411.8,0,1384,0,1355,0C1327.1,0,1299,0,1271,0C1242.4,0,1214,0,1186,0C1157.6,0,1129,0,1101,0C1072.9,0,1045,0,1016,0C988.2,0,960,0,932,0C903.5,0,875,0,847,0C818.8,0,791,0,762,0C734.1,0,706,0,678,0C649.4,0,621,0,593,0C564.7,0,536,0,508,0C480,0,452,0,424,0C395.3,0,367,0,339,0C310.6,0,282,0,254,0C225.9,0,198,0,169,0C141.2,0,113,0,85,0C56.5,0,28,0,14,0L0,0Z"></path></svg>

            <div class="background_gradient">
                <div class="container">
                    <div class="products_images_block">
                        <div class="product_block">
                            <img src="assets/img/cheese.png">
                            <p class="title_product wh">СЫР<br>мягкий "МУВЫРСКИЙ"</p>
                        </div>

                        <div class="product_block">
                            <img src="assets/img/smetana.png">
                            <p class="title_product wh">СМЕТАНА<br>мс мдж 20%</p>
                        </div>

                        <div class="product_block">
                            <img class="milk_pic" src="assets/img/milk25.png">
                            <p class="title_product wh">МОЛОКО<br>с мдж 2,5%</p>
                        </div>

                        <div class="product_block">
                            <img src="assets/img/milk32.png">
                            <p class="title_product wh">МОЛОКО<br>с мдж 3,2%</p>
                        </div>

                        <div class="product_block">
                            <img src="assets/img/milkfull.png">
                            <p class="title_product wh">МОЛОКО<br>цельное</p>
                        </div>

                        <div class="product_block">
                            <img class="milk_pic" src="assets/img/kefir25.png">
                            <p class="title_product wh">КЕФИР<br>с мдж 2,5%</p>
                        </div>

                        <div class="product_block">
                            <img src="assets/img/tvorog.png">
                            <p class="title_product wh">ТВОРОГ<br>с мдж 5%</p>
                        </div>

                        <div class="product_block">
                            <img src="assets/img/yogurt.png">
                            <p class="title_product wh">ЙОГУРТЫ<br>в ассортименте</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/production.blade.php ENDPATH**/ ?>