<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Дом fixme</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="intro_news intro_single_house">
        <header class="my-3">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img" >
                </button>
            </div>
        </header>
    </div>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="news_page">
        <div class="container container_news">
            <div class="house_box_img">
                <img src="/<?php echo e($house->img_house); ?>">
            </div>

            <p class="txt58 gr title_article"><?php echo e($house->title_house); ?></p>

            <p class="description_house txt24 my-5">
                <?php echo e(number_format($house->price_house, 2, ',', ' ')); ?> ₽
            </p>

            <p class="short_description descr justified_txt">
                <?php echo e($house->short_description_house); ?>

            </p>

            <p class="description_house my-5">
                <?php echo e($house->description_house); ?>

            </p>

            <form action="<?php echo e(route('bookingHouse')); ?>" method="get" class="login_form">
                <input type="hidden" value="<?php echo e($house->id_house); ?>" name="id_house_request">

                <label class="txt24 input_label">Дата заезда:<br> <input name="checkin_request" type="datetime-local"
                                                                         class="inputline" required></label><br><br><br>

                <label class="txt24 input_label">Дата выезда:<br> <input name="checkout_request" type="datetime-local"
                                                                         class="inputline" required></label><br><br><br>

                <label class="txt24 input_label">Количество человек: <br><input name="number_house_request" type="number"
                                                                                class="inputline" required></label><br><br><br>

                <div class="service_btn_block">
                    <button class="service_btn wh txt24">ДАЛЕЕ →</button>
                </div>
            </form>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/house.blade.php ENDPATH**/ ?>