<?php $__env->startSection('head'); ?>
    <title>Админ панель — Заявки на бронирование домиков</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding end_block">

        <div class="container my-4">
            <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="posts_block my-4">
                <p class="txt24 bl publ_txt">Заявки на аренду домов</p>
                <div class="scroll">
                    <table class="table ">
                        <thead class="table-dark thead">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID дома</th>
                            <th scope="col">ФИО</th>
                            <th scope="col">Телефон</th>
                            <th scope="col">Количество</th>
                            <th scope="col">Дата заезда</th>
                            <th scope="col">Дата выезда</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                        </tr>
                        </thead>
                        <tbody class="table-group-divider">
                        <?php if(count($houses) > 0): ?>
                            <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($house->id_request); ?></th>
                                    <td><a class="edit_a" href="<?php echo e(route('house', ['id' => $house->id_house_request])); ?>"><?php echo e($house->id_house_request); ?></a></td>
                                    <td><?php echo e($house->name_house_request); ?></td>
                                    <td><?php echo e($house->phone_house_request); ?></td>
                                    <td><?php echo e($house->number_house_request); ?></td>
                                    <td><?php echo e($house->checkin_request); ?></td>
                                    <td><?php echo e($house->checkout_request); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('deleteHouseReq')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("DELETE"); ?>
                                            <input type="hidden" name="id_request" value="<?php echo e($house->id_request); ?>">
                                            <button type="submit" class="del_a clearBtn">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <td>Нету</td>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cj90395/public_html/resources/views/admin/reqHouses.blade.php ENDPATH**/ ?>