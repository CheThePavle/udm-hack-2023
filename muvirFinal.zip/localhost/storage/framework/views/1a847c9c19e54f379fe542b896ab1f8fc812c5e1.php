<div class="admin_menu_block">
    <p>Пользователь: <b>ADMIN</b></p>
    <hr>
    <nav id="nav" class="nav_list">
        <ul class="admin_nav">
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('admin') ? 'fw-bold' : ''); ?>" href="<?php echo e(route('admin')); ?>">Мероприятия</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('adminFuns') ? 'fw-bold' : ''); ?>" href="<?php echo e(route('adminFuns')); ?>">Досуг</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('adminHouses') ? 'fw-bold' : ''); ?>" href="<?php echo e(route('adminHouses')); ?>">Дома</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('adminReqHouses') ? 'fw-bold' : ''); ?>" href="<?php echo e(route('adminReqHouses')); ?>">Аренда</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('adminExcursions') ? 'fw-bold' : ''); ?>" href="<?php echo e(route('adminExcursions')); ?>">Экскурсии</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('adminReqExcursions') ? 'fw-bold' : ''); ?>" href="<?php echo e(route('adminReqExcursions')); ?>">Завяки на экскурсии</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('adminWeddings') ? 'fw-bold' : ''); ?>" href="<?php echo e(route('adminWeddings')); ?>">Свадьбы</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('adminUsers') ? 'fw-bold' : ''); ?>" href="<?php echo e(route('adminUsers')); ?>">Администраторы</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>">Выход</a>
            </li>
        </ul>
    </nav>
    <hr>
</div>

<p class="succ">
    <?php echo e(session('msg')); ?>

</p>

<p class="err">
    <?php echo e(session('error')); ?>

</p>
<?php /**PATH C:\OpenServer\domains\muvir\resources\views/layouts/menuAdmin.blade.php ENDPATH**/ ?>