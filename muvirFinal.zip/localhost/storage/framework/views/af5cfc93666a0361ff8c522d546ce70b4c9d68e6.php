<?php $__env->startSection('head'); ?>
    <title>Админ панель — Услуги</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding end_block">

        <div class="container my-4">
            <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="posts_block my-4">
                <p class="txt24 bl publ_txt">Досуг</p>
                <a href="<?php echo e(route('adminFun')); ?>" class="more_info_white_btn">НОВАЯ УСЛУГА →</a>
                <div class="scroll">
                    <table class="table ">
                        <thead class="table-dark thead">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Название</th>
                            <th scope="col">Номер</th>
                            <th scope="col">Цена</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                        </tr>
                        </thead>
                        <tbody class="table-group-divider">
                        <?php if(count($funs) > 0): ?>
                            <?php $__currentLoopData = $funs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($fun->id_fun); ?></th>
                                    <td><?php echo e($fun->title_fun); ?></td>
                                    <td><?php echo e($fun->number_fun); ?></td>
                                    <td><?php echo e(number_format($fun->price_fun, 2, ',', ' ')); ?></td>
                                    <td><a href="<?php echo e(route('adminFunChange', ['id' => $fun->id_fun])); ?>" class="edit_a">Edit</a></td>
                                    <td>
                                        <form action="<?php echo e(route('deleteFun')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("DELETE"); ?>
                                            <input type="hidden" name="id_fun" value="<?php echo e($fun->id_fun); ?>">
                                            <button type="submit" class="del_a clearBtn">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <td>Нету</td>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/admin/funs.blade.php ENDPATH**/ ?>