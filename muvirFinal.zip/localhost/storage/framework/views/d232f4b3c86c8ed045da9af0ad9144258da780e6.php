<?php $__env->startSection('head'); ?>
    <title>Админ панель — Заявки на проведения свадеб</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding end_block">

        <div class="container my-4">
            <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="posts_block my-4">
                <p class="txt24 bl publ_txt">Заявки на проведение свадеб</p>
                <div class="scroll">
                    <table class="table ">
                        <thead class="table-dark thead">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Имя</th>
                            <th scope="col">Телефон</th>
                            <th scope="col">Дата</th>
                            <th scope="col"></th>
                        </tr>
                        </thead>
                        <tbody class="table-group-divider">
                        <?php if(count($weddings) > 0): ?>
                            <?php $__currentLoopData = $weddings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wedding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($wedding->id_wedding_request); ?></th>
                                    <td><?php echo e($wedding->name_wedding_request); ?></td>
                                    <td><?php echo e($wedding->phone_wedding_request); ?></td>
                                    <td><?php echo e($wedding->date_wedding_request); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('deleteWedding')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("DELETE"); ?>
                                            <input type="hidden" name="id_wedding_request" value="<?php echo e($wedding->id_wedding_request); ?>">
                                            <button type="submit" class="del_a clearBtn">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <td>Нету</td>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/admin/weddings.blade.php ENDPATH**/ ?>