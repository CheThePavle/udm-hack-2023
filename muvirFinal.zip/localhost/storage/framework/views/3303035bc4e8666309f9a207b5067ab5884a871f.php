<?php $__env->startSection('head'); ?>
    <title>Админ панель — Добавление услуги</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding end_block">

        <div class="container my-4">
            <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="posts_block my-4">
                <p class="txt24 bl publ_txt"><?php echo e(Route::is('adminFunChange') ? 'ИЗМЕНЕНИЕ УСЛУГИ' : 'НОВАЯ УСЛУГА'); ?></p>

                <form action="<?php echo e(Route::is('adminFunChange') ? route('changeFun') : route('createFun')); ?>" method="post" class="info_item" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <?php if(Route::is('adminFunChange')): ?>
                        <?php echo method_field("PATCH"); ?>

                        <input type="hidden" name="id_fun" value="<?php echo e($fun->id_fun); ?>">
                    <?php endif; ?>

                    <label class="add_input">Название: <br><input value="<?php echo e(Route::is('adminFunChange') ? $fun->title_fun : old('title_fun') ?? ''); ?>" name="title_fun" type="text"
                                                                  class="inputline add_input" placeholder="Название услуги" required maxlength="255"></label><br>

                    <?php if(Route::is('adminFunChange')): ?>
                        <img src="/<?php echo e($fun->img_fun); ?>" alt="img">
                    <?php endif; ?>
                    <label class="add_input"><?php echo e(Route::is('adminFunChange') ? 'Изменить ' : ''); ?> Фото: <input name="img_fun" type="file" placeholder="Фото" <?php echo e(Route::is('adminFunChange') ? '' : 'required'); ?>></label>

                    <label class="add_input">Описание: <br><textarea name="description_fun"
                                                                     placeholder="Описание услуги" class="add_input description"
                                                                     required><?php echo e(Route::is('adminFunChange') ? $fun->description_fun : old('description_fun') ?? ''); ?></textarea></label>

                    <label class="add_input">Телефон: <br><input value="<?php echo e(Route::is('adminFunChange') ? $fun->phone_fun : old('phone_fun') ?? ''); ?>" name="phone_fun" type="text"
                                                                 class="inputline add_input" placeholder="Телефон" required maxlength="11" minlength="11"></label>

                    <label class="add_input">Цена: <br><input value="<?php echo e(Route::is('adminFunChange') ? $fun->price_fun : old('price_fun') ?? ''); ?>" name="price_fun" type="number"
                                                              class="inputline add_input" placeholder="Цена услуги" required></label><br>

                    <button class="more_info_white_btn" type="submit"><?php echo e(Route::is('adminFunChange') ? 'Изменить' : 'Опубликовать'); ?></button>

                    <p class="err">
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </p>
                </form>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/admin/add/fun.blade.php ENDPATH**/ ?>