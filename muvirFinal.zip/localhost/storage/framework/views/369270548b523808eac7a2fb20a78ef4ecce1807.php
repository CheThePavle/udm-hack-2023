<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Свадьба</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="intro_article">
        <header class="my-3">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img">
                </button>
            </div>
        </header>

        <div class="intro__content position_intro_content">
            <div class="container">
                <h1 class="intro__title name_title">СВАДЬБА В МУВЫРЕ</h1>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="article_page">
        <div class="container container_news login_block">
            <p class="txt16 gr justified_txt">Укажите свой номер и имя и мы вам перезвоним, чтобы обсудить вашу свадьбу.</p>

            <form action="<?php echo e(route('createWedding')); ?>" method="post" class="login_form">
                <?php echo csrf_field(); ?>

                <label class="txt24 input_label">Ваш номер телефона:<br> <input name="phone_wedding_request" type="text"
                                                                                class="inputline" required maxlength="11" minlength="11"></label><br><br><br>

                <label class="txt24 input_label">Ваше имя:<br> <input name="name_wedding_request" type="text"
                                                                      maxlength="255" class="inputline" required></label><br><br><br>

                <div class="service_btn_block">
                    <button type="submit" class="service_btn wh txt24">ОТПРАВИТЬ →</button>
                </div>

                <p class="succ" id="msg">
                    <?php echo e(session('msg')); ?>

                </p>
            </form>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/weddings.blade.php ENDPATH**/ ?>