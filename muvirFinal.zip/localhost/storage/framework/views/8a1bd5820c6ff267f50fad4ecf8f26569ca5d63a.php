<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Инвесторам</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Инвесторам
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/investor.blade.php ENDPATH**/ ?>