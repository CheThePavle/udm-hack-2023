<?php $__env->startSection('head'); ?>
    <title>Админ панель — Добавление администратора</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding end_block">

        <div class="container my-4">
            <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="posts_block my-4">
                <p class="txt24 bl publ_txt"><?php echo e(Route::is('adminUserChange') ? 'ИЗМЕНЕНИЕ АДМИНИСТРАТОРА' : 'НОВЫЙ АДМИНИСТРАТОР'); ?></p>

                <form action="<?php echo e(Route::is('adminUserChange') ? route('userChange') : route('userCreate')); ?>" method="post" class="info_item">
                    <?php echo csrf_field(); ?>

                    <?php if(Route::is('adminUserChange')): ?>
                        <?php echo method_field("PATCH"); ?>

                        <input type="hidden" name="id_user" value="<?php echo e($user->id_user); ?>">
                    <?php endif; ?>

                    <label class="add_input">Фамилия: <br><input value="<?php echo e(Route::is('adminUserChange') ? $user->surname : old('surname') ?? ''); ?>" name="surname" type="text"
                                                                 class="inputline add_input" placeholder="Фамилия" required minlength="1" maxlength="255"></label>

                    <label class="add_input">Имя: <br><input value="<?php echo e(Route::is('adminUserChange') ? $user->name : old('name') ?? ''); ?>" name="name" type="text"
                                                             class="inputline add_input" placeholder="Имя" required minlength="1" maxlength="255"></label>

                    <label class="add_input">Отчество: <br><input value="<?php echo e(Route::is('adminUserChange') ? $user->patronymic : old('patronymic') ?? ''); ?>" name="patronymic" type="text"
                                                                  class="inputline add_input" placeholder="Отчество" minlength="1" maxlength="255"></label>

                    <label class="add_input">Телефон: <br><input value="<?php echo e(Route::is('adminUserChange') ? $user->phone : old('phone') ?? ''); ?>" name="phone" id="phone" type="text"
                                                                 class="inputline add_input" placeholder="Телефон администратора" required></label>

                    <label class="add_input">Логин: <br><input value="<?php echo e(Route::is('adminUserChange') ? $user->login : old('login') ?? ''); ?>" name="login" type="text"
                                                                  class="inputline add_input" placeholder="Логин администратора" required minlength="1" maxlength="255"></label><br>

                    <label class="add_input"><?php echo e(Route::is('adminUserChange') ? 'Новый ' : ''); ?>Пароль: <br><input name="password" type="password"
                                                                class="inputline add_input" placeholder="Пароль администратора" minlength="6" maxlength="255"></label>

                    <button class="more_info_white_btn" type="submit"><?php echo e(Route::is('adminUserChange') ? 'Изменить' : 'Создать'); ?></button>

                    <p class="err">
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </p>
                </form>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cj90395/public_html/resources/views/admin/add/user.blade.php ENDPATH**/ ?>