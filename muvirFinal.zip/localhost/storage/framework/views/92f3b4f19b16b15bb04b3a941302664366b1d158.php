<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Авторизация</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="intro_article">
        <header class="my-3">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img">
                </button>
            </div>
        </header>

        <div class="intro__content position_intro_content">
            <div class="container">
                <h1 class="intro__title name_title">ВХОД ДЛЯ АДМИНИСТРАТОРОВ</h1>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="article_page">
        <div class="container container_news login_block">
            <p class="txt16 gr justified_txt">Если вы являетесь администратором и забыли логин или пароль, пожалуйста,
                уточните его у вашего работодателя или главного администратора сайта.</p>

            <form action="<?php echo e(route('userAuth')); ?>" method="post" class="login_form">
                <?php echo csrf_field(); ?>

                <label class="txt24 input_label">Логин:<br> <input name="login" type="text" maxlength="255"
                                                                   class="inputline" required minlength="1"></label><br><br><br>
                <label class="txt24 input_label">Пароль: <br><input name="password" type="password" maxlength="255"
                                                                    class="inputline" required minlength="6"></label><br><br><br>

                <div class="service_btn_block">
                    <button type="submit" class="service_btn wh txt24">ВОЙТИ →</button>
                </div>

                
                <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="err">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\muvir\resources\views/login.blade.php ENDPATH**/ ?>