<?php $__env->startSection('head'); ?>
    <title><?php echo e(getenv('NAME_SITE')); ?> — Как добраться?</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Как добраться?
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/where.blade.php ENDPATH**/ ?>