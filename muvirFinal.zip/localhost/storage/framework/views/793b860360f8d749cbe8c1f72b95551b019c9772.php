<?php $__env->startSection('content'); ?>
    <div class="intro_article">
        <header class="my-3 header_OP">
            <div class="container">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img logo_img_OP">
                </a>

                <button class="menu_btn" id="menu_btn">
                    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img" >
                </button>

                <div class="intro__content position_intro_content">
                    <div class="container">
                        <h1 class="intro__title name_title">ВХОД ДЛЯ АДМИНИСТРАТОРОВ</h1>
                    </div>
                </div>
            </div>
        </header>
    </div>


    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <button class="menu_btn menu_btn_close" id="menu_btn_close">
        <img class="menu_btn_img" src="<?php echo e(asset('assets/img/close.svg')); ?>" id="menu_btn_img" >
    </button>

    <main class="article_page">
        <div class="container container_news login_block">
            <p class="txt16 gr justified_txt">Если вы являетесь администратором и забыли логин или пароль, пожалуйста, уточните его у вашего работодателя или главного администратора сайта.</p>

            <form action="<?php echo e(route('login')); ?>" method="post" class="login_form">
                <?php echo csrf_field(); ?>

                <label class="txt24 input_label">Логин:<br> <input name="login" type="text" value="<?php echo e(old('login')); ?>" maxlength="255" class="inputline <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required></label><br><br><br>
                <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label class="txt24 input_label">Пароль: <br><input name="password" type="password" maxlength="255" class="inputline <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required></label><br><br><br>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="service_btn_block">
                    <a href="" class="service_btn wh txt24">ВОЙТИ →</a>
                </div>
            </form>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\localhost\resources\views/auth/login.blade.php ENDPATH**/ ?>