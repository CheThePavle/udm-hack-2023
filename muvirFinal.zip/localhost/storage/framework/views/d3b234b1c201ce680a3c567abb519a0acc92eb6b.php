<nav id="nav" class="nav_list">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('fun')); ?>">Досуг в Мувыре</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('houses')); ?>">Гостевые домики</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('news')); ?>">Мероприятия</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('excursions')); ?>">Экскурсии</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('weddings')); ?>">Свадьба в Мувыре</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('where')); ?>">Как добраться?</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('map')); ?>">Интерактивная карта</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('about')); ?>">О нас</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('contact')); ?>">Контакты</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('production')); ?>">Производство</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('investor')); ?>">Инвесторам</a>
        </li>
    </ul>
</nav>

<button class="menu_btn menu_btn_close" id="menu_btn_close">
    <img class="menu_btn_img" src="<?php echo e(asset('assets/img/close.svg')); ?>" id="menu_btn_img">
</button>
<?php /**PATH C:\OSPanel\domains\muvir\resources\views/layouts/menu.blade.php ENDPATH**/ ?>