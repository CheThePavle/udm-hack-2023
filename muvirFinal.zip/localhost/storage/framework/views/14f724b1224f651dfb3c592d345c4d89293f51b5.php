<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/style/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/style/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/style/media.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/logoround.jpg')); ?>" type="image/jpeg">

    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
    <div class="wrap">
        <?php echo $__env->yieldContent('content'); ?>

        <footer>
            <div class="container">
                <div class="footer_content">
                    <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>">
                    <div class="footer_txt">
                        <div class="social_net">
                            <p class="wh">Мы в социальных сетях: </p>
                            <a href=""><img src="<?php echo e(asset('assets/img/vk.svg')); ?>"></a>
                            <a href=""><img src="<?php echo e(asset('assets/img/inst.svg')); ?>"></a>
                        </div>
                        <p class="num wh">+7 (901) 865 87 55</p>
                        <ul class="wh ul_footer txt24">
                            <li><a href="<?php echo e(route('about')); ?>">О нас</a></li>
                            <li><a href="<?php echo e(route('contact')); ?>">Контакты</a></li>
                            <li><a href="<?php echo e(route('production')); ?>">Производство</a></li>
                            <li><a href="<?php echo e(route('login')); ?>">Администраторам</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </footer>
    </div>

    <?php if(Route::is('index')): ?>
        <div class="video_player" id="videoPlayer">
            <iframe src="assets/img/video_player.mp4" width="900" height="500"
                    allow="encrypted-media; fullscreen; picture-in-picture;" frameborder="0" allowfullscreen></iframe>
            <button class="menu_btn menu_btn_close" id="menu_btn_close_video">
                <img class="menu_btn_img" src="assets/img/close.svg" id="menu_btn_img_video_close">
            </button>
        </div>
    <?php endif; ?>

    <script src="<?php echo e(asset('assets/scripts/imask.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/scripts/script.js')); ?>" defer></script>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\muvir\resources\views/layouts/app.blade.php ENDPATH**/ ?>