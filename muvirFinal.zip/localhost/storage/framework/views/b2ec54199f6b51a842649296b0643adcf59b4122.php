<?php $__env->startSection('head'); ?>
    <title>Админ панель — Добавление домика</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding end_block">

        <div class="container my-4">
            <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="posts_block my-4">
                <p class="txt24 bl publ_txt"><?php echo e(Route::is('adminChangeHouse') ? 'ИЗМЕНЕНИЕ ДОМА' : 'НОВЫЙ ДОМ'); ?></p>

                <form action="<?php echo e(Route::is('adminChangeHouse') ? route('changeHouse') : route('createHouse')); ?>" method="post" class="info_item" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <?php if(Route::is('adminChangeHouse')): ?>
                        <?php echo method_field("PATCH"); ?>

                        <input type="hidden" name="id_house" value="<?php echo e($house->id_house); ?>">
                    <?php endif; ?>

                    <label class="add_input">Название: <br><input value="<?php echo e(Route::is('adminChangeHouse') ? $house->title_house : old('title_house') ?? ''); ?>" name="title_house" type="text"
                                                                  class="inputline add_input" placeholder="Название гостевого дома" required maxlength="255"></label><br>

                    <?php if(Route::is('adminChangeHouse')): ?>
                        <img src="/<?php echo e($house->img_house); ?>" alt="img">
                    <?php endif; ?>
                    <label class="add_input">Фото: <input name="img_house" type="file" placeholder="Фото" <?php echo e(Route::is('adminChangeHouse') ? '' : 'required'); ?>></label>

                    <label class="add_input">Краткие данные: <br><textarea name="short_description_house"
                                                                           placeholder="Краткие данные о доме" class="add_input description"
                                                                           required maxlength="255"><?php echo e(Route::is('adminChangeHouse') ? $house->short_description_house : old('short_description_house') ?? ''); ?></textarea></label>

                    <label class="add_input">Описание: <br><textarea name="description_house"
                                                                     placeholder="Описание дома" class="add_input description"
                                                                     required><?php echo e(Route::is('adminChangeHouse') ? $house->description_house : old('description_house') ?? ''); ?></textarea></label>

                    <label class="add_input">Цена: <br><input value="<?php echo e(Route::is('adminChangeHouse') ? $house->price_house : old('price_house') ?? ''); ?>" name="price_house" type="text"
                                                              class="inputline add_input" placeholder="Цена услуги" required></label><br>

                    <button class="more_info_white_btn" type="submit"><?php echo e(Route::is('adminChangeHouse') ? 'Изменить' : 'Опубликовать'); ?></button>

                    <p class="err">
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </p>
                </form>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\udmHack\resources\views/admin/add/house.blade.php ENDPATH**/ ?>