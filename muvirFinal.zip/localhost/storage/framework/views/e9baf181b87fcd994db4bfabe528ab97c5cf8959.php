<?php $__env->startSection('head'); ?>
    <title>Админ панель — Добавление экскурсии</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding end_block">

        <div class="container my-4">
            <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="posts_block my-4">
                <p class="txt24 bl publ_txt"><?php echo e(Route::is('adminExcursionChange') ? 'ИЗМЕНЕНИЕ ЭКСКУРСИИ' : 'НОВАЯ ЭКСКУРСИЯ'); ?></p>

                <form action="<?php echo e(Route::is('adminExcursionChange') ? route('excursionChange') : route('createExcursion')); ?>" method="post" class="info_item" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <?php if(Route::is('adminExcursionChange')): ?>
                        <?php echo method_field("PATCH"); ?>

                        <input type="hidden" name="id_exc" value="<?php echo e($excursion->id_exc); ?>">
                    <?php endif; ?>

                    <label class="add_input">Название: <br><input value="<?php echo e(Route::is('adminExcursionChange') ? $excursion->title_exc : old('title_exc') ?? ''); ?>" name="title_exc" type="text" maxlength="255"
                                                                  class="inputline add_input" placeholder="Название экскурсии" required></label><br>

                    <?php if(Route::is('adminExcursionChange')): ?>
                        <img src="/<?php echo e($excursion->img_exc); ?>" alt="img">
                    <?php endif; ?>
                    <label class="add_input"><?php echo e(Route::is('adminExcursionChange') ? 'Изменить ' : ''); ?>Фото: <input name="img_exc" type="file" placeholder="Фото" <?php echo e(Route::is('adminExcursionChange') ? '' : 'required'); ?>></label>

                    <label class="add_input">Описание: <br><textarea name="description_exc"
                                                                     placeholder="Описание экскурсии" class="add_input description"
                                                                     required><?php echo e(Route::is('adminExcursionChange') ? $excursion->description_exc : old('description_exc') ?? ''); ?></textarea></label>

                    <label class="add_input">Телефон: <br><input value="<?php echo e(Route::is('adminExcursionChange') ? $excursion->phone_exc : old('phone_exc') ?? ''); ?>" name="phone_exc" type="text"
                                                                 class="inputline add_input" placeholder="Телефон" required id="phone"></label>

                    <label class="add_input">Цена: <br><input value="<?php echo e(Route::is('adminExcursionChange') ? $excursion->price_exc : old('price_exc') ?? ''); ?>" name="price_exc" type="text"
                                                              class="inputline add_input" placeholder="Цена экскурсии" required></label><br>

                    <button class="more_info_white_btn" type="submit"><?php echo e(Route::is('adminExcursionChange') ? 'Изменить' : 'Опубликовать'); ?></button>

                    <p class="err">
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </p>
                </form>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/admin/add/excursion.blade.php ENDPATH**/ ?>