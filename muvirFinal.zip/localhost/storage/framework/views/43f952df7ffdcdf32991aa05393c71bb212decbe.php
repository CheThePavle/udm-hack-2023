<?php $__env->startSection('head'); ?>
    <title>Админ панель — Экскурсии</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main_padding end_block">

        <div class="container my-4">
            <?php echo $__env->make('layouts.menuAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="posts_block my-4">
                <p class="txt24 bl publ_txt">Экскурсии</p>
                <a href="<?php echo e(route('adminExcursion')); ?>" class="more_info_white_btn">НОВАЯ ЭКСКУРСИЯ →</a>
                <div class="scroll">
                    <table class="table ">
                        <thead class="table-dark thead">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Название</th>
                            <th scope="col">Телефон</th>
                            <th scope="col">Цена</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                        </tr>
                        </thead>
                        <tbody class="table-group-divider">
                        <?php if(count($excursions) > 0): ?>
                            <?php $__currentLoopData = $excursions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $excursion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><a class="edit_a" href="<?php echo e(route('excursion', ['id' => $excursion->id_exc])); ?>"><?php echo e($excursion->id_exc); ?></a></th>
                                    <td><?php echo e($excursion->title_exc); ?></td>
                                    <td><?php echo e($excursion->phone_exc); ?></td>
                                    <td><?php echo e(number_format($excursion->price_exc, 2, ',', ' ')); ?></td>
                                    <td><a href="<?php echo e(route('adminExcursionChange', ['id' => $excursion->id_exc])); ?>" class="edit_a">Edit</a></td>
                                    <td>
                                        <form action="<?php echo e(route('deleteExcursion')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("DELETE"); ?>
                                            <input type="hidden" name="id_exc" value="<?php echo e($excursion->id_exc); ?>">
                                            <button type="submit" class="del_a clearBtn">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <td>Нету</td>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\muvir\resources\views/admin/excursions.blade.php ENDPATH**/ ?>