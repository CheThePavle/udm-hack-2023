<header class="my-3">
    <div class="container">
        <a href="<?php echo e(route('index')); ?>">
            <img src="<?php echo e(asset('assets/img/logoround.jpg')); ?>" class="logo_img">
        </a>

        <button class="menu_btn" id="menu_btn">
            <img class="menu_btn_img" src="<?php echo e(asset('assets/img/menu.svg')); ?>" id="menu_btn_img">
        </button>
    </div>
</header>
<?php /**PATH /home/c/cj90395/public_html/resources/views/layouts/headerAdmin.blade.php ENDPATH**/ ?>